import * as React from "react";
import {TextInput, Button, Text, View } from "react-native";

const s = require("./Styles")

function Alias({navigation}) {
    return(
        <View style={s.container}>
            <Text>Proporcione un Alias</Text>
            <TextInput style={s.input} />
            <Button 
                title='Continuar'
                onPress={() => navigation.navigate("Nivel")}
            />
        </View>
    );
}

export default Alias;