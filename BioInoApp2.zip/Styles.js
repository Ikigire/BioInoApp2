import { StyleSheet } from 'react-native';

module.exports = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    grid: (maxColumns = 4) => ({
        flex: maxColumns, // the number of columns you want to devide the screen into
        marginHorizontal: "auto",
        fontSize: 20,
        paddingHorizontal: 15,
        // marginHorizontal: 30,
        textAlign: 'center',
        justifyContent: 'center',
        width: '100%'
    }),
    title: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    row: {
        flexDirection: 'row'
    },
    "1col": {
        textAlign: 'center',
        justifyContent: 'center',
        marginHorizontal: 7,
        flex: 1
    },
    "2col": {
        flex: 2
    },
    "3col": {
        flex: 3
    },
    "4col": {
        flex: 4
    },
    fullContainer: {
        width: '100%',
    },
    centerContent: {
        flex: 1, // the number of columns you want to devide the screen into
        marginHorizontal: "auto",
        fontSize: 20,
        paddingHorizontal: 15,
        textAlign: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%'
    },
    cardContent: {
        paddingTop: 35,
        paddingBottom: 15,
        backgroundColor: 'black',
        width: '100%',
        minHeight: '20%',
        alignContent: 'flex-end',
        alignItems: 'center'
    },
    input: {
        marginTop: 25,
        width: '100%',
        minHeight: 45,
        textAlign: 'center',
        borderWidth: 3,
        borderColor: '#cfcfcf',
        borderRadius: 17,
        backgroundColor: '#f5f2f2',
        shadowColor: '#cfcfcf'
    },
    card: {
        width: '80%',
        marginRight: 40,
        marginLeft: 40,
        marginTop: 10,
        paddingTop: 20,
        paddingBottom: 20,
        backgroundColor: '#1D6FB8',
        borderRadius: 10,
        borderWidth: 1,
        color: '#fff',
        borderColor: '#fff',

        alignItems: 'center'
    },
    card_title: {
        color: '#fff',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: 26
    },
    card_text: {
        color: '#fff'
    },
    card_img: {
        height: '75%',
        overlayColor: '#fff',
        
    }
});