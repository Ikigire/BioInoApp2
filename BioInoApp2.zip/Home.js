import { Button, Text, View } from "react-native";

const s = require("./Styles")

function Home({navigation}) {
    return(
        <View style={s.container}>
            <Text>Home Screen!</Text>
            <Button 
                title='Añadir Dispositivo'
                onPress={() => navigation.navigate("Electric")}
            />
        </View>
    );
}

export default Home;