import React, { Component } from "react";
import { Text, View, StyleSheet, Pressable, TextInput } from "react-native";
import FlashMessage from "react-native-flash-message";

globalStyle = require("./Styles");

class Signin extends Component {
  constructor() {
    super();
    this.state = {
      disabled: false,
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    };
  }

  handleRegister = () => {
    this.setState({ disabled: true });

    if (!this.state.username || !this.state.email || !this.state.password || !this.state.confirmPassword) {
      this.refs.myLocalFlashMessage.showMessage({
        message: "Faltan campos por llenar",
        type: "danger",
      });

      this.setState({ disabled: false });
      return;
    }

    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    if (!emailRegex.test(this.state.email)) {
      this.refs.myLocalFlashMessage.showMessage({
        message: "Correo electrónico inválido",
        type: "danger",
      });

      this.setState({ disabled: false });
      return;
    }

    fetch(`http://3.133.59.124:4000/checkEmail/${this.state.email}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.emailExists) {
          this.refs.myLocalFlashMessage.showMessage({
            message: "El correo electrónico ya está en uso.",
            type: "danger",
          });

          this.setState({ disabled: false });
        } else {
          if (this.state.password !== this.state.confirmPassword) {
            this.refs.myLocalFlashMessage.showMessage({
              message: "Las contraseñas no coinciden",
              type: "danger",
            });

            this.setState({ disabled: false });
            return;
          }

          const newUser = {
            nombre: this.state.username,
            email: this.state.email,
            password: this.state.password,
            rol: "usuario",
          };

          fetch("http://3.133.59.124:4000/registro", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(newUser),
          })
            .then((response) => response.json())
            .then((data) => {
              console.log("Usuario registrado con éxito:", data);

              this.refs.myLocalFlashMessage.showMessage({
                message: "Registro exitoso",
                type: "success",
              });

              this.props.navigation.navigate("Login");

              this.setState({ disabled: false });
            })
            .catch((error) => {
              console.error("Error al registrar el usuario:", error);
              this.setState({ disabled: false });
            });
        }
      })
      .catch((error) => {
        console.error("Error al verificar el correo electrónico:", error);
        this.setState({ disabled: false });
      });
  };

  render() {
    return (
      <View style={{ width: "100%", height: "100%" }}>
        <TextInput
          style={globalStyle.input}
          placeholder="Nombre usuario"
          autoCapitalize="words"
          value={this.state.username}
          onChangeText={(text) => this.setState({ username: text })}
        />
        <TextInput
          style={globalStyle.input}
          placeholder="Correo"
          autoCompleteType="email"
          autoCapitalize="none"
          value={this.state.email}
          onChangeText={(text) => this.setState({ email: text })}
        />
        <TextInput
          style={globalStyle.input}
          placeholder="Contraseña (letras y números)"
          autoCapitalize="none"
          secureTextEntry={true}
          value={this.state.password}
          onChangeText={(text) => this.setState({ password: text })}
        />
        <TextInput
          style={globalStyle.input}
          placeholder="Confirmar contraseña"
          autoCapitalize="none"
          secureTextEntry={true}
          value={this.state.confirmPassword}
          onChangeText={(text) => this.setState({ confirmPassword: text })}
        />

        <View style={{ paddingTop: 15, marginBottom: 5 }}>
          <Pressable onPress={this.handleRegister} disabled={this.state.disabled}>
            <Text style={styles.activeButton}>Registrar</Text>
          </Pressable>
        </View>

        {/* Componente FlashMessage para mostrar notificaciones */}
        <FlashMessage ref="myLocalFlashMessage" position="bottom" />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  activeButton: {
    height: 50,
    width: "98%",
    borderRadius: 25,
    textAlign: "center",
    color: "white",
    backgroundColor: "#0390fc",
    textAlignVertical: "center",
    alignSelf: "center",
  },
});

export default Signin;
