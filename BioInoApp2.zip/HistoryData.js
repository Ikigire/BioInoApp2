import { useEffect, useState } from "react";
import { Text, View, Image, ActivityIndicator, ScrollView } from "react-native";
import styles from './Styles';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Device from "./components/Device";

const s = require("./Styles")

function HistoryData({ route }) {
    const { device } = route.params;

    const [history, setHistory] = useState([]);

    useEffect(() => {
        console.log(device);
        setTimeout(() => {
            setHistory(prev => ['abc', ...prev]);
        }, 3000);
    }, [])

    return (
        // <View style={{fontSize: 20, flex: 1, paddingHorizontal: 30, marginHorizontal: 30, textAlign: 'left', justifyContent: 'left', justifyContent: "center"}}>
        <View style={[s.container]}>
            <Device device={device} connect={false} />
            <View style={[{ display: 'flex', justifyContent: 'center' }]}>
                <Text>{'Cantidad'}</Text>
                <Image source={require('./assets/co2gra.jpg')} style={{ width: 200, height: 180 }} />
                <Text>{'Tiempo \n'}</Text>
                <Text>{'Sensor Valor Actual \n'}</Text>
                <Text>{'03                550PPM'}</Text>
            </View>
            <ScrollView style={[{ width: '100%', marginTop: 4 }]}>
                {/* <View style={[{ display: 'flex', justifyContent: 'center' }]}>
                    <Text>{'Cantidad'}</Text>
                    <Image source={require('./assets/co2gra.jpg')} style={{ width: 270, height: 250 }} />
                    <Text>{'Tiempo \n'}</Text>
                    <Text>{'Sensor Valor Actual \n'}</Text>
                    <Text>{'03                550PPM'}</Text>
                </View> */}

                <View style={[{ width: '100%' }]}>
                    {
                        history.length ?
                            (
                                <>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                    <View style={[{ borderColor: '#ff4d55', borderWidth: 2, padding: 4 }]}>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Dispositivo {device.idDispositivo}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Humedad: {58}</Text>
                                        <Text style={[{ textAlign: 'center', width: '100%' }]}> Temperatura {30}</Text>
                                    </View>
                                </>
                            )
                            :
                            (
                                <>
                                    <ActivityIndicator size={'large'} />
                                </>
                            )
                    }
                </View>
            </ScrollView>

        </View>

    );
}

export default HistoryData;