import React, { Component } from "react";
import { Button, Text, View, StyleSheet, ScrollView, Pressable } from "react-native";
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

s = require("./Styles")


class Ubicacion extends Component {
    keyCounter = 0;
    constructor() {
        super();
        this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    }

    forceUpdateHandler() {
        this.forceUpdate();
    }


    homeIcons = [
        { icon: 'knife', text: 'Cocina' },
        { icon: 'toilet', text: 'Baño' },
        { icon: 'bed-queen-outline', text: 'Sala' },
        { icon: 'bed-empty', text: 'Cuarto' },
        { icon: 'stairs', text: 'Escaleras' },
        { icon: 'arm-flex-outline', text: 'Gimnasio' },
        { icon: 'baby-bottle', text: 'Cuarto Bebé' },
        { icon: 'car', text: 'Garage' },
        { icon: 'water', text: 'Lavandería' },
        { icon: 'water-polo', text: 'Piscina' },
        { icon: 'flower', text: 'Jardín' },
        { icon: 'food', text: 'Comedor' },
        { icon: 'hand-saw', text: 'Bodega' },
        { icon: 'cellphone-link', text: 'Estudio' },
        { icon: 'google-controller', text: 'Sala de Juegos' },
        { icon: 'grill', text: 'Terraza' }
    ];

    hospitalIcons = [
        { icon: 'office-building', text: 'Consultorio' },
        { icon: 'cash-register', text: 'Recepción' },
        { icon: 'dna', text: 'Sala de estudios' },
        { icon: 'mother-heart', text: 'Sala Maternidad' },
        { icon: 'hospital', text: 'Urgencias'},
        { icon: 'baby-face', text: 'Incubadora'},
        { icon: 'coffee-maker', text: 'Comedor'},
        { icon: 'hospital', text: 'Urgencias'},
        { icon: 'truck', text: 'Estacionamiento'},
        { icon: 'skull-outline', text: 'Rayos X'},
        { icon: 'seat', text: 'Sala de Espera'},
        { icon: 'bed', text: 'Habitación'},
        { icon: 'meditation', text: 'Psicología'},
        { icon: 'tooth', text: 'Dentista'},
        { icon: 'food-apple', text: 'Nutrición'},
        { icon: 'heart', text: 'Cardiología'},
        { icon: 'stomach', text: 'Gastroenterología'},
        { icon: 'brain', text: 'Neurología'},
        { icon: 'face-woman', text: 'Ginecología'},
        { icon: 'human-handsdown', text: 'Dermatología'},
        { icon: 'face-agent', text: 'Urología'},
        { icon: 'skull-crossbones', text: 'Traumatología'},
        { icon: 'panda', text: 'Pediatría'},
        { icon: 'virus', text: 'Oncología'}
    ]

    escuelaIcons = [
        { icon: 'school', text: 'Dirección' },
        { icon: 'bowl-mix', text: 'Cafetería' },
        { icon: 'brush', text: 'Salón de Arte' },
        { icon: 'bus-school', text: 'Estacionamiento' },
        { icon: 'desktop-mac', text: 'Aula de Cómputo'},
        { icon: 'basketball', text: 'Auditorio'},
        { icon: 'gate', text: 'Entrada'},
        { icon: 'human-child', text: 'Aula'},
        { icon: 'soccer', text: 'Cancha'},
        { icon: 'doctor', text: 'Enfermería'},
        { icon: 'music', text: 'Sala de Música'},
        { icon: 'note', text: 'Servicios Administrativos'}
    ]

    officeIcons = [
        { icon: 'seat', text: 'Recepción' },
        { icon: 'cookie', text: 'Cocina' },
        { icon: 'toilet', text: 'Baño' },
        { icon: 'folder-multiple', text: 'Archivo' }
    ]

    selectedIcon = '';

    conditionalStyles = StyleSheet.create({
        active: (valueIcon) => {
            const bgColor = valueIcon == this.selectedIcon ? '#0390fc' : 'transparent';
            const txtColor = valueIcon == this.selectedIcon ? 'white' : 'black';
            const borderRadius = 10;
            // const borderRadius = valueIcon == this.selectedIcon ? 10 : 0;
            return {
                backgroundColor: bgColor,
                color: txtColor,
                borderRadius: borderRadius,
                textAlign: 'center'
            }
        },
        activeButton: (disabled) => {
            const bgColor = !disabled ? '#0390fc': 'gray';
            return {
                height: 50,
                width: '98%',
                borderRadius: 25,
                textAlign: 'center',
                color: 'white',
                backgroundColor: bgColor,
                verticalAlign: 'middle',
                alignSelf: 'center'
            }
        }
    })

    changeSelectedIcon(icon) {
        if (icon == this.selectedIcon) {
            this.selectedIcon = ''
        } else {
            this.selectedIcon = icon;
        }
        // alert('Icon seleccionado ' + selectedIcon);
        this.forceUpdateHandler();
    }

    renderOptionRow(iconArray) {
        const Col = ({ numCols, children }) => {
          return (
            <View style={s[`${numCols}col`]}>{children}</View>
          )
        }
    
        const Row = ({ children }) => (
          <View style={s.row}>{children}</View>
        )
    
        const IconSelectable = ({ text, icon = null, icon_size = 25, onPress = null }) => {
          if (!onPress) {
            onPress = () => { this.changeSelectedIcon(text) }
          }
    
          if (icon == null) {
            return (
              <Pressable onPress={onPress} key={this.keyCounter++}>
                <Text>{'\n' + text}</Text>
              </Pressable>
            )
          } else {
            return (
              <Pressable onPress={onPress} key={this.keyCounter++}>
                <Text style={this.conditionalStyles.active(text)}>
                  <MaterialCommunityIcons name={icon} size={icon_size} />{'\n' + text}
                </Text>
              </Pressable>
            );
          }
        }
    
        let rows = [];
        let components = [];
    
        // Reiniciar el contador
        this.keyCounter = 0;
    
        let c = 0; // Corregir error: declarar la variable c
    
        for (let index = 0; index < iconArray.length; index++) {
          const icon = iconArray[index];
          c++;
          if (c <= 4) {
            components.push(
              <Col numCols={1} key={this.keyCounter++}>
                <IconSelectable text={icon.text} icon={icon.icon} icon_size={60} />
              </Col>
            );
          }
          if (c >= 4 || index === iconArray.length - 1) {
            rows.push(
              <Row key={this.keyCounter++}>
                {components}
              </Row>
            );
            components = [];
            c = 0;
          }
        }
        return rows;
    }

    render() {
        return (
            <View style={{ width: '100%', height: '100%' }}>
                <ScrollView>
                    <View style={s.imagesGrid}>
                        <Text style={s.title}>{'Hogar \n'}</Text>
                        {this.renderOptionRow(this.homeIcons)}

                        <Text style={s.title}>{'\n Hospital\n'}</Text>
                        {this.renderOptionRow(this.hospitalIcons)}
                        
                        <Text style={s.title}>{'\n Escuela\n'}</Text>
                        {this.renderOptionRow(this.escuelaIcons)}

                        <Text style={s.title}>{'\n Oficina\n'}</Text>
                        {this.renderOptionRow(this.officeIcons)}
                    </View>
                </ScrollView>

                <View style={{ paddingTop: 15, marginBottom: 5 }}>
                    <Pressable onPress={() => { alert('El item seleccionado es: ' + this.selectedIcon); this.props.navigation.navigate("Root");}} disabled={!this.selectedIcon}>
                        <Text style={this.conditionalStyles.activeButton(!this.selectedIcon)} >Aceptar</Text>
                    </Pressable>
                    {/* <Button
                        title='Aceptar'
                        disabled={!this.selectedIcon}
                        color={'#0390fc'}
                        onPress={() => this.props.navigation.navigate("Root")}
                    /> */}
                </View>
            </View>
        );
    }
}

export default Ubicacion;