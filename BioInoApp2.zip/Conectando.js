import * as React from "react";
import { Button, Text, View } from "react-native";
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const s = require("./Styles")

function Conectando({ navigation }) {
    return (
        <View style={{ fontSize: 20, flex: 1, paddingHorizontal: 30, marginHorizontal: 30, textAlign: 'left', justifyContent: 'center', alignItems: "center" }}>
            <Text>Conectando con Sensor X</Text>
            <MaterialCommunityIcons name="vanish" size={250} />
            <Button
                title='Aceptar'
                onPress={() => navigation.navigate("Nombre")}
            />
        </View>
    );
}

export default Conectando;