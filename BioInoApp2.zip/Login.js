import React, { Component } from "react";
import { Animated, Text, View, StyleSheet, Pressable, TextInput } from "react-native";

globalStyle = require("./Styles")


class Login extends Component {
    constructor() {
        super();
        this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    }

    forceUpdateHandler() {
        this.forceUpdate();
    }

    conditionalStyles = StyleSheet.create({
        active: (valueIcon) => {
            const bgColor = valueIcon == this.selectedIcon ? '#0390fc' : 'transparent';
            const txtColor = valueIcon == this.selectedIcon ? 'white' : 'black';
            const borderRadius = 10;
            // const borderRadius = valueIcon == this.selectedIcon ? 10 : 0;
            return {
                backgroundColor: bgColor,
                color: txtColor,
                borderRadius: borderRadius,
                textAlign: 'center'
            }
        },
        activeButton: (disabled) => {
            const bgColor = !disabled ? '#0390fc' : 'gray';
            return {
                height: 50,
                width: '35%',
                borderRadius: 25,
                textAlign: 'center',
                color: 'white',
                backgroundColor: bgColor,
                verticalAlign: 'middle',
                alignSelf: 'center'
            }
        }
    })


    render() {
        return (
            <View style={{ width: '100%', height: '100%' }}>
                <View style={[globalStyle.centerContent]}>
                    <Text style={[globalStyle.title]}>Iniciar Sesión</Text>

                    <TextInput
                        style={globalStyle.input}
                        placeholder='Correo'
                        autoComplete="email"
                        autoCapitalize="none"
                    />
                    <TextInput
                        style={globalStyle.input}
                        placeholder='Contraseña (letras y números)'
                        autoCapitalize="none"
                    />
                </View>

                <View style={{ paddingTop: 15, marginBottom: 5 }}>
                    <Pressable onPress={() => { this.props.navigation.navigate("Root"); }} disabled={false}>
                        <Text style={this.conditionalStyles.activeButton(false)} >Iniciar sesión</Text>
                    </Pressable>
                </View>

                <View style={globalStyle.centerContent}>
                    <Text style={[globalStyle.title, {paddingBottom: 25}]}> ¿No tienes cuenta?</Text>
                    <Pressable onPress={ () => this.props.navigation.navigate("Signin")} >
                        <Text>Registrate aquí</Text>
                    </Pressable>
                    <Pressable onPress={ () => this.props.navigation.navigate("PassRecovery")} style={{marginTop: 15}} >
                        <Text style={globalStyle.title} >¿Olvisate tu contraseña?</Text>
                    </Pressable>
                </View>

                <View style={{minHeight: 50, width: '100%', backgroundColor: '#0390fc'}}>
                </View>
            </View>
        );
    }
}

export default Login;